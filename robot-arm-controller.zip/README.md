# Robot Arm Controller

A simple PHP + MySQL web interface for saving robot arm motor values into a database.

## Features

- Submit 6 motor values through a form
- Store values in a MySQL database
- Basic error checking

## Tech Stack

- PHP (Procedural)
- MySQL (XAMPP)
- HTML

## Database Schema

Create a database called `robot_arm`, and run the following SQL:

```sql
CREATE TABLE Poses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    motor1 VARCHAR(10),
    motor2 VARCHAR(10),
    motor3 VARCHAR(10),
    motor4 VARCHAR(10),
    motor5 VARCHAR(10),
    motor6 VARCHAR(10),
    statusx VARCHAR(5),
    created VARCHAR(50)
);
```

## Usage

1. Place files in `htdocs/robot-arm-controller/`
2. Run XAMPP server (Apache + MySQL)
3. Go to `http://localhost/robot-arm-controller/index.html`
4. Submit values
5. Check them in phpMyAdmin

## Screenshots

### ✅ Form with Data
![Form Output](screenshots/form-output.png)

### 📨 POST Data Preview
![Form POST](screenshots/form-post-preview.png)

### ✅ Successful Insert Message
![Success Insert](screenshots/success-insert.png)

## Author

Developed by [Your Name]
