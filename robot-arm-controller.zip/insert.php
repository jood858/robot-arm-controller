<?php
include 'db_config.php';

$motor1 = $_POST["motor1"];
$motor2 = $_POST["motor2"];
$motor3 = $_POST["motor3"];
$motor4 = $_POST["motor4"];
$motor5 = $_POST["motor5"];
$motor6 = $_POST["motor6"];

if (!empty($motor1) && !empty($motor2) && !empty($motor3) && !empty($motor4) && !empty($motor5) && !empty($motor6)) {
    $sql = "INSERT INTO Poses (motor1, motor2, motor3, motor4, motor5, motor6, statusx, created)
            VALUES ('$motor1', '$motor2', '$motor3', '$motor4', '$motor5', '$motor6', '0', '')";

    if ($conn->query($sql) === TRUE) {
        echo "✅ New record created successfully.";
    } else {
        echo "❌ Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "❗ Missing motor values.";
}

$conn->close();
?>